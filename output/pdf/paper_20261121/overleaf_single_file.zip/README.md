# Editable paper for Overleaf

This project contains the whole paper in `main.tex`, including all sections,
tables, equations, and the 18 reference entries. The class and PDF figures are
included as supporting files.

1. In Overleaf, choose New Project, then Upload Project, and upload this ZIP.
2. Use `main.tex` as the main document and select the pdfLaTeX compiler.
3. Edit the manuscript directly in `main.tex` and click Recompile.
4. Use Overleaf's Share button to give your professor project access, or send
   this ZIP and the separately supplied review PDF.

References are inline in the `thebibliography` environment near the end of
`main.tex`. Citation keys are preserved. No BibTeX run is required for this
single-file version.

Keep `IEEEtai.cls` and `figures/` with the manuscript. The draft uses the
professor's supplied class without changes. After major edits, adjust or remove
`\IEEEtriggeratref{10}` if the final reference columns no longer balance.

This is the 21 November 2026 author-review draft. Author details, professor
review, and independent label review remain pending.
